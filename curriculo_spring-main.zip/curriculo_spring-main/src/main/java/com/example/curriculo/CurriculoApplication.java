package com.example.curriculo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurriculoApplication {

    public static void main(String[] args) {
        SpringApplication.run(CurriculoApplication.class, args);
    }

}
