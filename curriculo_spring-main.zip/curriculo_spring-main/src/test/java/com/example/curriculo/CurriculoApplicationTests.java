package com.example.curriculo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurriculoApplicationTests {

    @Test
    void contextLoads() {
    }

}
